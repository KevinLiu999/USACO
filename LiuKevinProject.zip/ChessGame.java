
public class ChessGame {

	private ChessBoard board;

	public ChessGame() {
		board = new ChessBoard();
	}

	private static ChessGame game;
	private static ChessPiece selectedPiece;
	private static boolean playerOneTurn;

	public static void main(String[] args) {
		run();
	}

	private static void run() {

		System.out.println("Welcome to Chess!");

		game = new ChessGame();

		playerOneTurn = true;

		while (true) {

			boolean origTurn = playerOneTurn;

			System.out.println(game.board.toString());
			System.out.println("");

			System.out.print("Player's Turn: ");
			if (playerOneTurn) {
				System.out.println("W");
			} else {
				System.out.println("B");
			}

			do {
				readSelectCoordinate();
				readTargetCoordinate();
			} while (origTurn == playerOneTurn);

			// check for checkmate
			// after move check if still in check

		}

	}

	private static void readSelectCoordinate() {

		System.out.print("Enter the coordinates of the piece you would like to select (Ex. b4): ");

		String coordinate = TextIO.getln();
		if (!isValidSelect(coordinate)) {
			do {
				System.out.print("Error, try again: ");
				coordinate = TextIO.getln();
			} while (!isValidSelect(coordinate));
		}

	}

	private static boolean isValidSelect(String s) {

		if (s.length() != 2) {
			return false;
		}
		if (s.toLowerCase().charAt(0) - 'a' < 0 || s.toLowerCase().charAt(0) - 'a' >= 8) {
			return false;
		}
		try {
			Integer.parseInt("" + s.charAt(1));
		} catch (Exception e) {
			return false;
		}
		if (Integer.parseInt("" + s.charAt(1)) < 1 || Integer.parseInt("" + s.charAt(1)) > 8) {
			return false;
		}

		boolean ret = false;
		for (ChessPiece piece : (playerOneTurn ? game.board.getWhitePieces() : game.board.getBlackPieces())) {
			if (s.toLowerCase().charAt(0) - 'a' + 1 == piece.getColumn()
					&& 9 - Integer.parseInt("" + s.charAt(1)) == piece.getRow()) {
				selectedPiece = piece;
				ret = true;
			}
		}
		return ret;

	}

	private static void readTargetCoordinate() {

		System.out.print("Enter the coordinates of the target square (Ex. b4): ");

		String coordinate = TextIO.getln();
		if (!isValidTarget(coordinate)) {
			System.out.println("Error: Invalid Target Square");
			return;
		}

		if (playerOneTurn) {
			for (int i = 0; i < game.board.getWhitePieces().size(); i++) {
				ChessPiece piece = game.board.getWhitePieces().get(i);
				if (piece.getRow() == selectedPiece.getRow() && piece.getColumn() == selectedPiece.getColumn()) {
					game.board.getWhitePieces().get(i).setRow(9 - Integer.parseInt("" + coordinate.charAt(1)));
					game.board.getWhitePieces().get(i).setColumn(coordinate.toLowerCase().charAt(0) - 'a' + 1);
				}
			}
			for (int i = 0; i < game.board.getBlackPieces().size(); i++) {
				ChessPiece piece = game.board.getBlackPieces().get(i);
				if (piece.getRow() == 9 - Integer.parseInt("" + coordinate.charAt(1))
						&& piece.getColumn() == coordinate.toLowerCase().charAt(0) - 'a' + 1) {
					game.board.getBlackPieces().remove(i);
					break;
				}
			}
		} else {
			for (int i = 0; i < game.board.getWhitePieces().size(); i++) {
				ChessPiece piece = game.board.getWhitePieces().get(i);
				if (piece.getRow() == 9 - Integer.parseInt("" + coordinate.charAt(1))
						&& piece.getColumn() == coordinate.toLowerCase().charAt(0) - 'a' + 1) {
					game.board.getWhitePieces().remove(i);
					break;
				}
			}
			for (int i = 0; i < game.board.getBlackPieces().size(); i++) {
				ChessPiece piece = game.board.getBlackPieces().get(i);
				if (piece.getRow() == selectedPiece.getRow() && piece.getColumn() == selectedPiece.getColumn()) {
					game.board.getBlackPieces().get(i).setRow(9 - Integer.parseInt("" + coordinate.charAt(1)));
					game.board.getBlackPieces().get(i).setColumn(coordinate.toLowerCase().charAt(0) - 'a' + 1);
				}
			}
		}

		playerOneTurn = !playerOneTurn;

	}

	private static boolean isValidTarget(String s) {

		if (s.length() != 2) {
			return false;
		}
		if (s.toLowerCase().charAt(0) - 'a' < 0 || s.toLowerCase().charAt(0) - 'a' >= 8) {
			return false;
		}
		try {
			Integer.parseInt("" + s.charAt(1));
		} catch (Exception e) {
			return false;
		}
		if (Integer.parseInt("" + s.charAt(1)) < 1 || Integer.parseInt("" + s.charAt(1)) > 8) {
			return false;
		}

		return game.board.valid(Integer.parseInt("" + s.charAt(1)), s.toLowerCase().charAt(0) - 'a' + 1, selectedPiece);

	}

}
