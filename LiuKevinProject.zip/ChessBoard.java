import java.util.ArrayList;

public class ChessBoard {

	private ArrayList<ChessPiece> whitePieces;
	private ArrayList<ChessPiece> blackPieces;

	public ChessBoard() {
		whitePieces = new ArrayList<ChessPiece>();
		blackPieces = new ArrayList<ChessPiece>();
		for (int i = 0; i < 8; i++) {
			whitePieces.add(new Pawn(7, i + 1));
			blackPieces.add(new Pawn(2, i + 1));
		}
		for (int i = 0; i < 2; i++) {
			whitePieces.add(new Knight(8, i == 0 ? 2 : 7));
			blackPieces.add(new Knight(1, i == 0 ? 2 : 7));
		}
		for (int i = 0; i < 2; i++) {
			whitePieces.add(new Bishop(8, i == 0 ? 3 : 6));
			blackPieces.add(new Bishop(1, i == 0 ? 3 : 6));
		}
		for (int i = 0; i < 2; i++) {
			whitePieces.add(new Rook(8, i == 0 ? 1 : 8));
			blackPieces.add(new Rook(1, i == 0 ? 1 : 8));
		}
		whitePieces.add(new Queen(8, 4));
		blackPieces.add(new Queen(1, 4));
		whitePieces.add(new King(8, 5));
		blackPieces.add(new King(1, 5));
	}

	public ArrayList<ChessPiece> getWhitePieces() {
		return whitePieces;
	}

	public void setWhitePieces(ArrayList<ChessPiece> whitePieces) {
		this.whitePieces = whitePieces;
	}

	public ArrayList<ChessPiece> getBlackPieces() {
		return blackPieces;
	}

	public void setBlackPieces(ArrayList<ChessPiece> blackPieces) {
		this.blackPieces = blackPieces;
	}

	public boolean valid(int row, int column, ChessPiece piece) {
		ArrayList<Coordinate> list = piece.findValidCoordinates(piece.getRow(), piece.getColumn(), whitePieces,
				blackPieces);
		for (Coordinate c : list) {
			if (c.getX() == 9 - row && c.getY() == column) {
				return true;
			}
		}
		return false;
	}

	public String toString() {
		String ret = "    ";
		for (int i = 1; i <= 40; i++) {
			if (i % 5 != 0) {
				ret += "_";
			} else {
				ret += " ";
			}
		}
		ret += "\n";
		for (int i = 1; i <= 8; i++) {
			ret += " " + (9 - i) + " |";
			for (int j = 1; j <= 8; j++) {
				boolean occupied = false;
				ret += " ";
				for (ChessPiece piece : whitePieces) {
					if (piece.getRow() == i && piece.getColumn() == j) {
						ret += "W" + piece.getRef();
						occupied = true;
					}
				}
				for (ChessPiece piece : blackPieces) {
					if (piece.getRow() == i && piece.getColumn() == j) {
						ret += "B" + piece.getRef();
						occupied = true;
					}
				}
				if (!occupied) {
					ret += "  ";
				}
				ret += " |";
			}
			ret += "\n   |";
			for (int j = 1; j <= 8; j++) {
				ret += "____|";
			}
			ret += "\n";
		}
		ret += "     a    b    c    d    e    f    g    h";
		return ret;
	}

}
