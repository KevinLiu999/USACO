import java.util.ArrayList;

public class Rook extends ChessPiece {

	private int[][] dir;

	public Rook(int row, int column) {
		super("Rook", 'R', row, column);
		dir = new int[28][2];
		for (int i = 1; i <= 7; i++) {
			dir[i - 1][0] = -i;
			dir[i + 6][1] = -i;
			dir[i + 13][0] = i;
			dir[i + 20][1] = i;
		}
	}

	public ArrayList<Coordinate> findValidCoordinates(int row, int column, ArrayList<ChessPiece> whitePieces,
			ArrayList<ChessPiece> blackPieces) {

		boolean playerOneTurn = false;

		for (ChessPiece piece : whitePieces) {
			if (piece.getRow() == row && piece.getColumn() == column) {
				playerOneTurn = true;
			}
		}

		ArrayList<Coordinate> ret = new ArrayList<Coordinate>();

		for (int i = 0; i < 28; i++) {

			int nx = row + dir[i][0];
			int ny = column + dir[i][1];

			boolean cont = false;

			for (ChessPiece piece : (playerOneTurn ? whitePieces : blackPieces)) {
				if ((piece.getRow() == nx && piece.getColumn() == ny) || nx < 1 || nx > 8 || ny < 1 || ny > 8) {
					if (i < 7) {
						i = 6;
					} else if (i >= 7 && i < 14) {
						i = 13;
					} else if (i >= 14 && i < 21) {
						i = 20;
					} else if (i >= 21) {
						i = 27;
					}
					cont = true;
					break;
				}
			}
			if (cont) {
				continue;
			}
			for (ChessPiece piece : (playerOneTurn ? blackPieces : whitePieces)) {
				if ((piece.getRow() == nx && piece.getColumn() == ny) || nx < 1 || nx > 8 || ny < 1 || ny > 8) {
					ret.add(new Coordinate(nx, ny));
					if (i < 7) {
						i = 6;
					} else if (i >= 7 && i < 14) {
						i = 13;
					} else if (i >= 14 && i < 21) {
						i = 20;
					} else if (i >= 21) {
						i = 27;
					}
					cont = true;
					break;
				}
			}
			if (cont) {
				continue;
			}

			ret.add(new Coordinate(nx, ny));

		}

		return ret;

	}

}
