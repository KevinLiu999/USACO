import java.util.ArrayList;

public class King extends ChessPiece {

	private int[][] dir;

	public King(int row, int column) {
		super("King", 'K', row, column);
		dir = new int[][] { { -1, -1 }, { -1, 0 }, { -1, 1 }, { 0, 1 }, { 1, 1 }, { 1, 0 }, { 1, -1 }, { 0, -1 } };
	}

	public ArrayList<Coordinate> findValidCoordinates(int row, int column, ArrayList<ChessPiece> whitePieces,
			ArrayList<ChessPiece> blackPieces) {

		boolean playerOneTurn = false;

		for (ChessPiece piece : whitePieces) {
			if (piece.getRow() == row && piece.getColumn() == column) {
				playerOneTurn = true;
			}
		}

		ArrayList<Coordinate> ret = new ArrayList<Coordinate>();

		for (int i = 0; i < 8; i++) {

			int nx = dir[i][0] + row;
			int ny = dir[i][1] + column;

			if (nx < 1 || nx > 8 || ny < 1 || ny > 8) {
				continue;
			}

			boolean cont = false;

			for (ChessPiece piece : (playerOneTurn ? whitePieces : blackPieces)) {
				if (piece.getRow() == nx && piece.getColumn() == ny) {
					cont = true;
					break;
				}
			}
			if (cont) {
				continue;
			}

			ret.add(new Coordinate(nx, ny));

			// check for checks and checkmates

		}

		return ret;

	}

}
