import java.util.ArrayList;

public class Pawn extends ChessPiece {

	private int[][] dir;

	public Pawn(int row, int column) {
		super("Pawn", 'P', row, column);
		dir = new int[][] { { 2, 0 }, { 1, 0 }, { 1, -1 }, { 1, 1 } };
	}

	public ArrayList<Coordinate> findValidCoordinates(int row, int column, ArrayList<ChessPiece> whitePieces,
			ArrayList<ChessPiece> blackPieces) {

		boolean playerOneTurn = false;

		for (ChessPiece piece : whitePieces) {
			if (piece.getRow() == row && piece.getColumn() == column) {
				playerOneTurn = true;
			}
		}

		ArrayList<Coordinate> ret = new ArrayList<Coordinate>();

		for (int i = 0; i < 4; i++) {

			int nx = dir[i][0] + row;
			int ny = dir[i][1] + column;
			nx -= playerOneTurn ? 2 * dir[i][0] : 0;

			if (nx < 1 || nx > 8 || ny < 1 || ny > 8) {
				continue;
			}
			if (i == 0 && row != (playerOneTurn ? 7 : 2)) {
				continue;
			}

			boolean hasOther = false;

			if (i < 2) {
				for (ChessPiece piece : whitePieces) {
					if (piece.getRow() == nx && piece.getColumn() == ny) {
						hasOther = true;
					}
				}
				for (ChessPiece piece : blackPieces) {
					if (piece.getRow() == nx && piece.getColumn() == ny) {
						hasOther = true;
					}
				}
				if (hasOther) {
					continue;
				}
			}

			hasOther = false;

			if (i >= 2) {
				for (ChessPiece piece : (playerOneTurn ? blackPieces : whitePieces)) {
					if (piece.getRow() == nx && piece.getColumn() == ny) {
						hasOther = true;
					}
				}
				if (!hasOther) {
					continue;
				}
			}

			ret.add(new Coordinate(nx, ny));

		}
		
		// check for en passant and promotion

		return ret;
		
	}

}
