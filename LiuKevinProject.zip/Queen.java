import java.util.ArrayList;

public class Queen extends ChessPiece {

	private int[][] dir;

	public Queen(int row, int column) {
		super("Queen", 'Q', row, column);
		dir = new int[56][2];
		for (int i = 1; i <= 7; i++) {
			dir[i - 1][0] = -i;
			dir[i - 1][1] = -i;
			dir[i + 6][0] = -i;
			dir[i + 6][1] = i;
			dir[i + 13][0] = i;
			dir[i + 13][1] = i;
			dir[i + 20][0] = i;
			dir[i + 20][1] = -i;
			dir[i + 27][0] = -i;
			dir[i + 34][1] = -i;
			dir[i + 41][0] = i;
			dir[i + 48][1] = i;
		}
	}

	public ArrayList<Coordinate> findValidCoordinates(int row, int column, ArrayList<ChessPiece> whitePieces,
			ArrayList<ChessPiece> blackPieces) {

		boolean playerOneTurn = false;

		for (ChessPiece piece : whitePieces) {
			if (piece.getRow() == row && piece.getColumn() == column) {
				playerOneTurn = true;
			}
		}

		ArrayList<Coordinate> ret = new ArrayList<Coordinate>();

		for (int i = 0; i < 56; i++) {

			int nx = row + dir[i][0];
			int ny = column + dir[i][1];

			boolean cont = false;

			for (ChessPiece piece : (playerOneTurn ? whitePieces : blackPieces)) {
				if ((piece.getRow() == nx && piece.getColumn() == ny) || nx < 1 || nx > 8 || ny < 1 || ny > 8) {
					if (i < 7) {
						i = 6;
					} else if (i >= 7 && i < 14) {
						i = 13;
					} else if (i >= 14 && i < 21) {
						i = 20;
					} else if (i >= 21 && i < 28) {
						i = 27;
					} else if (i >= 28 && i < 35) {
						i = 34;
					} else if (i >= 35 && i < 42) {
						i = 41;
					} else if (i >= 42 && i < 49) {
						i = 48;
					} else if (i >= 49) {
						i = 55;
					}
					cont = true;
					break;
				}
			}
			if (cont) {
				continue;
			}
			for (ChessPiece piece : (playerOneTurn ? blackPieces : whitePieces)) {
				if ((piece.getRow() == nx && piece.getColumn() == ny) || nx < 1 || nx > 8 || ny < 1 || ny > 8) {
					ret.add(new Coordinate(nx, ny));
					if (i < 7) {
						i = 6;
					} else if (i >= 7 && i < 14) {
						i = 13;
					} else if (i >= 14 && i < 21) {
						i = 20;
					} else if (i >= 21 && i < 28) {
						i = 27;
					} else if (i >= 28 && i < 35) {
						i = 34;
					} else if (i >= 35 && i < 42) {
						i = 41;
					} else if (i >= 42 && i < 49) {
						i = 48;
					} else if (i >= 49) {
						i = 55;
					}
					cont = true;
					break;
				}
			}
			if (cont) {
				continue;
			}

			ret.add(new Coordinate(nx, ny));

		}

		for (Coordinate c : ret) {
			System.out.println(c.getX() + " " + c.getY());
		}

		return ret;

	}

}
