import java.util.ArrayList;

public abstract class ChessPiece {

	private String name;
	private char ref;
	private int row, column;

	public ChessPiece(String name, char ref, int row, int column) {
		this.name = name;
		this.ref = ref;
		this.row = row;
		this.column = column;
	}

	public String getName() {
		return name;
	}

	public char getRef() {
		return ref;
	}

	public int getRow() {
		return row;
	}

	public void setRow(int row) {
		this.row = row;
	}

	public int getColumn() {
		return column;
	}

	public void setColumn(int column) {
		this.column = column;
	}

	abstract ArrayList<Coordinate> findValidCoordinates(int row, int column, ArrayList<ChessPiece> whitePieces,
			ArrayList<ChessPiece> blackPieces);

}
