import java.util.ArrayList;

public class Knight extends ChessPiece {

	private int[][] dir;

	public Knight(int row, int column) {
		super("Knight", 'N', row, column);
		dir = new int[][] { { -1, -2 }, { -2, -1 }, { -2, 1 }, { -1, 2 }, { 1, 2 }, { 2, 1 }, { 2, -1 }, { 1, -2 } };
	}

	public ArrayList<Coordinate> findValidCoordinates(int row, int column, ArrayList<ChessPiece> whitePieces,
			ArrayList<ChessPiece> blackPieces) {
		
		boolean playerOneTurn = false;

		for (ChessPiece piece : whitePieces) {
			if (piece.getRow() == row && piece.getColumn() == column) {
				playerOneTurn = true;
			}
		}

		ArrayList<Coordinate> ret = new ArrayList<Coordinate>();

		for (int i = 0; i < 8; i++) {
			
			int nx = row + dir[i][0];
			int ny = column + dir[i][1];
			
			if (nx < 1 || nx > 8 || ny < 1 || ny > 8) {
				continue;
			}
			
			boolean cont = false;

			for (ChessPiece piece : (playerOneTurn ? whitePieces : blackPieces)) {
				if (piece.getRow() == nx && piece.getColumn() == ny) {
					cont = true;
					break;
				}
			}
			if (cont) {
				continue;
			}
			
			ret.add(new Coordinate(nx, ny));
			
		}
		
		return ret;

	}

}
